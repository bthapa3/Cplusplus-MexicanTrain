#pragma once
#include "Player.h"
#include "Tile.h"
#include "Deck.h"
#include "User.h"
#include "Computer.h"
#include "Train.h"
#include <iomanip>
#include <fstream>
class Round
{	
	public:
		Round() {
			currentRound = 0;
			engineTile = Tile();
			usertrainmarked = false;
			computertrainmarked = false;
			gameover = false;
			playerscore = 0;
			computerscore = 0;

		};
		Round(int round) {
			currentRound = round;
			usertrainmarked = false;
			computertrainmarked = false;
			gameover = false;
			playerscore = 0;
			computerscore = 0;
		}
		~Round() {};
		void Initializegame();
		void DisplayGame();
		void PlayMoves(bool userfirst, int round);
		bool Playpossible();
		inline int playerRoundscore() {
			return playerscore;
		}
		inline int computerRoundscore() {
			return computerscore;
		}
		void DisplayComputerdouble(int spacing);

		void DisplayComputerMiddleTile(int spacing);
		void DisplayPlayerMiddleTile(int spacing);
		void DisplayPlayerDouble(int spacing);

		void DisplayMexicanMiddleTile(int spacing);
		void DisplayMexicanDouble(int spacing);

		void DisplayallTiles(vector<Tile> tiles);

		void SerializeandQuit();

	private:
		int currentRound;
		vector <Tile> boneyardTiles;
		
		//this is the engine tile
		Tile engineTile;

		//this is the boneyard tile
		vector<Tile> BoneyardTiles;

		//three trains for the user. mexican and the computer
		Train * trainsList[3];
		
		//User player and the computer player
		Player * playersList[2];

		bool usertrainmarked;
		bool computertrainmarked;
		bool gameover;
		int playerscore;
		int computerscore;

};

