#include "User.h"
using namespace std;

bool User::PlayMove(Train* trainslist[], vector<Tile> &boneyard, int continuedmove, bool & quit)
{
	cout << "-------------USER TURN----------------" << endl;
	
	unsigned int tilenumber = 0;
	//if the tile chosen can be attached with train chosen.
	bool validtile = false;
	bool replay = false;
	bool boneyardtile = false;
	//validating the tilenumber so that user chooses a valid tilenumber to play
	while(!validtile)
	{
		
		char input='X';
		
		do {

			//if the same players turn is repeated twice.
			if (continuedmove >= 1) {
				cout << "You have one more move as you played a double tile" << endl;
				cout << "-----------------------------------------------------" << endl;
			}

			input = Displayoptions();
			if (input == 'H') {
				Playsuggestor(trainslist, boneyard, continuedmove);
			}
			if (input == 'S') {
				cout << "serializing" << endl;
				quit = true;
				return false;
			}

			
		} while (input != 'U' && input != 'C' && input != 'M' && input != 'B' && input != 'H');

		if (input == 'B') {
			
			Tile boneyardtile = boneyard.at(0);
			cout << "_____________________________________________________________________________________" << endl;
			cout << "Picked boneyard tile is: " << boneyardtile.GetSide1() << '-' << boneyardtile.GetSide2() << endl;
			cout << "Place it to a valid train or press B again to skip your turn" << endl;
			cout << "_____________________________________________________________________________________" << endl;


			//if statement is true only if there was a tile on a boneyard.
			//else turn is skipped 

			if (PickBoneyard(boneyard, **(trainslist))) {
				BoneyardtoTrain(trainslist, replay, validtile,continuedmove);
			}
			return false;
			
		}
		
		if ((input == 'U' || input == 'C' || input == 'M'))
		{
			
			char train = input;
			char orphandoubletrain = 'X';

			//if a player has to play a orphan double train or pickup a boneyard tile


			if ((continuedmove < 1) && OrphanDoublePresent(trainslist, orphandoubletrain))
			{   
				while (train != orphandoubletrain && train !='B')
				{
					cout << "You must play on Orphan double Train! or Select boneyard tile" << endl;
					cout << ">>";
					cin >> train;
					

				}
				//one more time user can play
				if (train == 'B') {
					//take him to boneyard tile path.
					Tile boneyardtile = boneyard.at(0);
					cout << "Picked boneyard tile is" << boneyardtile.GetSide1() << '-' << boneyardtile.GetSide2() << endl;
					if (PickBoneyard(boneyard, **(trainslist))) {
						BoneyardtoTrain(trainslist, replay, validtile,continuedmove);
					}
					return false;
				}

			}
			
			
			//more validation to be done here.
			if (train == 'U')
			{
				
				if (continuedmove == 1) {

					if (CheckandPlace(trainslist, **(trainslist), replay, validtile, "User")) {
						(**(trainslist)).RemoveMark();
					}
				}
				else {
					PlaceTiletoTrain(**(trainslist), replay, validtile, "User");
					if ((**(trainslist)).isTrainMarked())
					{
						(**(trainslist)).RemoveMark();
					}
				}
				
			}
			else if (train == 'C')
			{
				
				if ((**(trainslist+1)).isTrainMarked() || orphandoubletrain == 'C')
				{
					if (continuedmove == 1) {

						CheckandPlace(trainslist, **(trainslist + 1), replay, validtile, "Computer");
					}
					else {
						PlaceTiletoTrain(**(trainslist + 1), replay, validtile, "Computer");
					}	
		
				}
				else {
					cout << "You cannot add tiles to unmarked computer's train" << endl;
				}

			}
			else if (train == 'M')
			{
				if (continuedmove == 1) {

					CheckandPlace(trainslist, **(trainslist + 2), replay, validtile, "Mexican");
				}
				else {
					PlaceTiletoTrain(**(trainslist + 2), replay, validtile, "Mexican");
				}
				
			}
			else {
				cout << "Sorry the tile you gave cannot be played on the chosen Train! Pick Boneyard tiles if no moves are valid." << endl;
			}


		}

	}
	return replay;
}



void User::BoneyardtoTrain(Train* trainslist[], bool& replay, bool& validtile , int continuedmove)
{
	Tile toptile = GetPlayerTiles().back();
	char a_train = 'X';
	Tile tile_to_match;
	string dummyinput;
	if (OrphanDoublePresent(trainslist, a_train) && continuedmove==0) {
		if (a_train == 'U') {
			if (CheckTrainMove(**(trainslist), toptile, GetPlayerTiles().size())) {
				cout << "Tile added to orphan double train" << endl;
				cout << "Press Y to continue>>" << endl;
				cin >> dummyinput;
				return;
			}
		}
		else if (a_train == 'C') {
			if (CheckTrainMove(**(trainslist + 1), toptile, GetPlayerTiles().size())) {
				cout << "Tile added to orphan double train" << endl;
				cout << "Press y to continue>>" << endl;
				cin >> dummyinput;
				return;
			}
		}
		else {
			if (CheckTrainMove(**(trainslist + 2), toptile, GetPlayerTiles().size())) {
				cout << "Tile added to orphan double train" << endl;
				cout << "Press y to continue>>" << endl;
				cin >> dummyinput;
				return;
			}
		}

		cout << "------------------------------------------------------------------------------" << endl;
		cout << "Tile doesnot fit for the orphan double train! Will be added to the players list " << endl;
		cout << " Press y to continue" << endl;
		cin >> dummyinput;
		cout << "------------------------------------------------------------------------------" << endl;

	}
	else {
		while (!validtile)
		{
			char input = Displayoptions();
			if (input == 'B') {
				validtile = true;
			}
			else if (input == 'U') {
				PlaceCustomTiletoTrain(**(trainslist), replay, validtile, "User", GetPlayerTiles().size());
				(**(trainslist)).RemoveMark();
			}
			else if (input == 'C')
			{
				if ((**(trainslist + 1)).isTrainMarked())
				{

					PlaceCustomTiletoTrain(**(trainslist + 1), replay, validtile, "Computer", GetPlayerTiles().size());

				}
				else {
					cout << "You cannot add tiles to unmarked computer's train" << endl;
				}

			}
			else if (input == 'M') {
				PlaceCustomTiletoTrain(**(trainslist + 2), replay, validtile, "Mexican", GetPlayerTiles().size());
			}
			else {
				cout << "Sorry Cannot use boneyard tile! Please pass turn by choosing B" << endl;
			}
		}
	}


}

void User::Playsuggestor(Train* trainslist[], vector<Tile>& boneyard, int continuedmove)
{

	int tilenumber;
	Train train;
	bool turn_repeat = false;
	char traintype;

	//check if there is a orphan double train present
	if (continuedmove == 0 && OrphanDoublePresent(trainslist, traintype)) {
		//move to the orphan double train as needed.
		if (traintype == 'U' && (SuggestOrphanMove(trainslist, **trainslist))) return ;
		if (traintype == 'M' && (SuggestOrphanMove(trainslist, **(trainslist + 2)))) return ;
		if (traintype == 'C' && (SuggestOrphanMove(trainslist, **(trainslist + 1)))) return;

		cout << "You donot have valid tile to play trains. Pick boneyard tiles and mark the train"<< endl;
		cout << "If there are no boneyard tiles left just mark the train and continue" << endl;
		//here needs to be press any key to conitnue.
		return;

	}
	//checks if the mexican train is empty if so adds tile if available.
	if (StartMexicanTrain(trainslist, tilenumber, train)) {
		DisplaySuggestion(tilenumber, train, "it starts the mexican train");
		return ;
	}

	// second argument **trainslist+1 is the train of the opponent player as current player is computer.
	if (Playopponenttrain(trainslist, **(trainslist+1), tilenumber, train)) {
		DisplaySuggestion(tilenumber, train, "the opponent train has marker");
		return ;
	}


	//check if you can force other player to play orphan double train & orphan double cannot be played more than two times.
	if (PlayOrphanDoublemove(trainslist, tilenumber, train, **(trainslist+1)) && continuedmove < 2) {
		Tile mytile = GetPlayerTiles().at(tilenumber - 1);
		if ((continuedmove == 0) || (continuedmove == 1 && validsecondDouble(trainslist, train, mytile))) {
			DisplaySuggestion(tilenumber, train, "it forces opponent to play orphan double train");
			return ;
		}
	}


	int mexicantile, mexicansum, selftile, selfsum;
	Train mexicantrain, selftrain;

	bool can_playmexican = PlayMexicanTrain(trainslist, tilenumber, train);
	if (can_playmexican) {
		mexicantile = tilenumber;
		mexicansum = GetPlayerTiles().at(tilenumber - 1).GetSide1() + GetPlayerTiles().at(tilenumber - 1).GetSide2();
		mexicantrain = train;
	}

	bool can_playself = PlaySelfTrain(trainslist, tilenumber, **(trainslist));
	if (can_playself) {
		selftile = tilenumber;
		selfsum = GetPlayerTiles().at(tilenumber - 1).GetSide1() + GetPlayerTiles().at(tilenumber - 1).GetSide2();
		selftrain = **(trainslist);
	}

	//if the computer played double tile before on the computer or mexican train try not to play itself
	// if computer played double tile on user train still will try to play on opponent train as per winning strategy.
	//continued move means the user has played a double tile before.
	if (continuedmove == 1) {
		OrphanDoublePresent(trainslist, traintype);
		if (traintype == 'C' && can_playmexican) {
			DisplaySuggestion(mexicantile, **(trainslist + 2), "it is the largest possible tile to play and helps for orphan double");
			return;
		}
		else if (traintype == 'M' && can_playself) {
			DisplaySuggestion(selftile, **(trainslist), "it is the largest possible tile to play and helps for orphan double");
			return;
		}
	}


	if (((can_playmexican && can_playself) && selfsum >= mexicansum) || (can_playself && !can_playmexican)) {

		DisplaySuggestion(selftile, **(trainslist), "it is the largest possible tile to play");
		return;

	}
	else if (((can_playmexican && can_playself) && selfsum < mexicansum) || (!can_playself && can_playmexican)) {

		DisplaySuggestion(mexicantile, **(trainslist + 2), "it is the largest possible tile to play");
		return;
	}
	else {

		cout << "You donot have any valid tiles to play. So pick a tile from boneyard to continue" << endl;
		//DisplayandContinue();
		return;

	}
}


bool User::SuggestOrphanMove(Train* trainslist[], Train& train)
{

	if (CanPlayinTrain(train)) {

		int tilenumber = GetPlayableTile(train);
		DisplaySuggestion(tilenumber, train, "it is the orphan double train");
		return true;
	}
}


void User::DisplaySuggestion(int tilenumber, Train train, string message) {

	string tile = to_string(GetPlayerTiles().at(tilenumber - 1).GetSide1()) + '-' + to_string(GetPlayerTiles().at(tilenumber - 1).GetSide2());
	string trainname = train.trainType();
	cout << "Move tile: " << tile << " to "<< train.trainType() << " as " << message << endl;
	cout << "---------------------------------------------------------------------------------" << endl;
	cout << "Enter y to continue>>";
	string dummyinput;
	cin >> dummyinput;
}



