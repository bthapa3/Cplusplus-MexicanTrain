// MexicanTrain.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
using namespace std;


#include <iostream>
#include "Game.h"
int main()
{

    Game newgame = Game();
    newgame.startGame();
   
   
}
 
